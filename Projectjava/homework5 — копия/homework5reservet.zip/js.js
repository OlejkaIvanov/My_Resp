const chess = {
  gameContainerEl: document.getElementById('game'),
  render() {
  	// Названия колонок
    const cols = [0, 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 0];
    const rows = [0, '8', '7', '6', '5', '4', '3', '2', '1', 0];
    const blackFigures = [0, '&#9820;', '&#9822;', '&#9821;', '&#9819;', '&#9818;', '&#9821;', '&#9822;', '&#9820;', 0];
    const blackFigures2 = [0, '&#9823;', '&#9823;', '&#9823;', '&#9823;', '&#9823;', '&#9823;', '&#9823;', '&#9823;', 0];
    const whiteFigures = [0,'&#9814;', '&#9816;', '&#9815;', '&#9812;', '&#9813;', '&#9815;', '&#9816;', '&#9814;', 0];
    const whiteFigures2 = [0, '&#9817;', '&#9817;', '&#9817;', '&#9817;', '&#9817;', '&#9817;', '&#9817;', '&#9817;', 0];

        for (let row = 0; row < 10; row++) {
    	// Создаем и добавляем строку.
      const tr = document.createElement('tr');
      this.gameContainerEl.appendChild(tr);
			
      // Добавляем ячейки в строку.
      for (let col = 0; col < 10; col++) {
      	// Создаем и добавляем ячейку.
        const td = document.createElement('td');
        tr.appendChild(td);
      
        
        if (row === 0 && cols[col] !== 0) {
          td.innerHTML = cols[col];
        } 

        if (row === 9 && cols[col] !== 0) {
          td.innerHTML = cols[col];
        } 
       
        if (col === 0 && rows[row] !== 0) {
          td.innerHTML = rows[row];
        } 

        if (col === 9 && rows[row] !== 0) {
          td.innerHTML = rows[row];
        } 


        // Проверяем, надо ли покрасить ячейку, передаем строку и колонку.
        if (this.isCellIsBlack(row, col)) {
          td.style.backgroundColor = 'grey'
      }  
    }
  }
},



	// Метод определяет нужно ли покрасить ячейку.
  // Просто для примера покрасим ячейки, строки которых делятся на 2 с остатком.
  isCellIsBlack(rowNum, colNum) {
  	// Если будет остаток, то он даст true в условии, а если не будет, то 0 даст false в условии.
    return rowNum % 2;
  },
};

// Запускаем метод render.
chess.render();